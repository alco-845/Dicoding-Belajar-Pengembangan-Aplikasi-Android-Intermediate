package com.alcorp.storyapp.helper

object PrefData {
    var token: String = ""
}